# Perintah
    $ pkg update && upgrade
    $ pkg install git
    $ pkg install python
    $ pip install requests
    $ pip install futures
    $ git clone https://github.com/AhmadFahrurrozi/Crack-ig
    $ cd Crack-ig
    $ git pull
    $ python Prem.py
